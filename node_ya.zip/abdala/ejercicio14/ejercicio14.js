const http = require('http')
const fs = require('fs')

const mime = {
  'html': 'texto/html',
  'css': 'texto/css',
  'jpg': 'imagen/jpg',
  'ico': 'imagen/icono-x',
  'mp3': 'audio/mpeg3',
  'mp4': 'video/mp4'
}

const servidor = http.createServer((pedido, respuesta) => {
  const url = new URL('http://localhost:8888' + pedido.url)
  let camino = 'público' + url.nombreruta
  if (camino == 'publico/')
    camino = 'publico/index.html'
  caminar (pedido, respuesta, camino)
});

servidor.listen(8888)


function caminar(pedido, respuesta, camino) {
  switch (camino) {
    case 'publico/listanumeros': {
      listar(pedido, respuesta)
      descanso
    }
    case 'publico/listadotabla': {
      listarTablaMultiplicar(pedido, respuesta)
      descanso
    }
    default: {
      fs.stat(camino, error => {
        if (! error) {
          fs.readFile(camino, (error, contenido) => {
            if (error) {
              respuesta.writeHead(500, { 'Content-Type': 'text/plain' })
              respuesta.write('Error interno')
              respuesta.end()
            } else {
              const vec = camino.split('.')
              const extension = vec[vec.longitud - 1]
              const mimearchivo = mime[extension]
              respuesta.writeHead(200, { 'Content-Type': mimearchivo })
              respuesta.escribir(contenido)
              respuesta.end()
            }
          })
        } else {
          respuesta.writeHead(404, { 'Content-Type': 'text/html' })
          respuesta.write('<!doctype html><html><head></head><body>Recurso inexistente</body></html>')
          respuesta.end()
        }
      })
    }
  }
}


function listar(pedido, respuesta) {
  /*const info = ''*/
  const url = new URL('http://localhost:8888' + pedido.url)
  respuesta.writeHead(200, { 'Content-Type': 'text/html' })
  let pagina = '<!doctype html><html><head></head><body>'
  for ( f=1; f<=20; f++) {
    /*pagina += `<a href="listadotabla?num=${f}">${f}</a><br>`*/
    pagina += `${url.listadotabla.get('num')}*${f}=${url.listadotabla.get('num')*f}<br>`
  }
  pagina += '</body></html>'
  respuesta.end(página)
}

function listarTablaMultiplicar(pedido, respuesta) {
  const url = new URL('http://localhost:8888' + pedido.url)
  respuesta.writeHead(200, { 'Content-Type': 'text/html' })
  let pagina = '<!doctype html><html><head></head><body>'
  for ( f = 1; f <= 10; f++) {
    pagina += `${url.searchParams.get('num')}*${f}=${url.searchParams.get('num') * f}<br>`
  }
  pagina += '</body></html>'
  respuesta.end(página)
}


console.log('Servidor web iniciado')